import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SessionManagement } from '@pristine/process/SessionManagement';
import { LeadsService } from '../leads.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';


@Component({
  selector: 'create-edit-leads',
  templateUrl: './create-edit-leads.component.html',
  styleUrls: ['./create-edit-leads.component.scss']
})
export class CreateEditLeadsComponent implements OnInit {

  constructor(
    private _fb: FormBuilder,
    private _session: SessionManagement,
    private leadService: LeadsService,
    public dialog: MatDialog
    ) { }
  image: string ='mat_solid:person'
  uploadedImage: any
  LeadCreate: FormGroup
  email_opt_out: boolean=false
  // @Input() set saveChanges (val: boolean){
  //   console.log(val)
  //   if(val){
  //     console.log('save here')
  //     this.SubmitChanges()
  //   }
  // }
  // get saveChanges(){
  //   return false
  // }
  ngOnInit(): void {
    this.LeadCreate = this._fb.group({
      lead_owner: [this._session.getEmail],
      company: ['',Validators.required],
      first_name: [''],
      last_name: ['',Validators.required],
      title: [''],
      email: ['', Validators.email],
      fax: [''],
      phone: [''],
      mobile: [''],
      website: [''],
      lead_source: [''],
      lead_status: [''],
      industry: [''],
      no_of_employees: [Number(0), Validators.min(0) ],
      annual_revenue: [Number(0), Validators.min(0)],
      rating: [],
      // email_opt_out: [false],
      skype_id: [''],
      secondary_email: ['', Validators.email],
      twitter: [''],
      street: [''],
      city: [''],
      state: [''],
      zipcode: [''],
      country: [''],
      description: ['']
    })

    this.leadService.saveFile.subscribe(res=>{
      console.log(res)
      if(res){
        console.log('save here')
        this.SubmitChanges()
      }
    })
  }

  uploadImage(){
    let fileInput = document.createElement('input')
    fileInput.setAttribute('type','file')
    fileInput.click()
    fileInput.addEventListener('change', event =>{
      var file = (<HTMLInputElement>event.target).files[0];
      let fileReader = new FileReader();
          fileReader.onload = (e) => {
            this.uploadedImage = fileReader.result;
            console.log(this.uploadImage)
          }
       
    })
  }

  SubmitChanges(){
    if(this.LeadCreate.invalid){
      console.log('Invalid')
      return
    }
    this.leadService.createLead(this.LeadCreate.value)
  }

  openDialog()
  {
    this.dialog.open(task_create,{width:'600px',height:'500px'});
  }
  openMeeting()
  {
    this.dialog.open(meeting_create,{width:'600px',height:'600px'});
  }
}

@Component({
  selector: 'lead_comp_dialog',
  templateUrl: 'task_create.html',
})
export class task_create implements OnInit{
  constructor(public dialog:MatDialog) {
  }
  ngOnInit() {

  }
  option_ckeck:any=''
    opt_owner:any=''
  openOtherDia(ref:any)
  {
    this.dialog.open(ref)
  }
}

@Component({
  selector: 'meeting_create',
  templateUrl: 'meeting_create.html',
})
export class meeting_create implements OnInit{
  constructor(public dialog:MatDialog,private _fb: FormBuilder) {}
  ngOnInit() {}
  hello(e:any){
    if(e.checked){
      this.chechedOption++
    }else{
      this.chechedOption--
    }
  }
  option_host:any=''
  openDialog(ref:any){
    this.dialog.open(ref)
  }
  option_ckeck:any='None'
  SearchbyOption:any='Contact'
  chechedOption:number=0
  meeting_reminder:any=[]
  reminder_meeting(ele:any){
    this.meeting_reminder.push(ele)
  }
  delete_reminder(index:any){
    this.meeting_reminder.splice(index,1)
  }

  show_more_details:boolean=true

}