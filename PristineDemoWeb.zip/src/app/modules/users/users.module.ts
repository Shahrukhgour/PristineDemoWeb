import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersProfileComponent } from './profile/users_Profile.component';
import { Routes, RouterModule} from  '@angular/router'
import { SharedModule } from 'app/shared/shared.module';
import {MatMenuModule} from '@angular/material/menu';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {MatDividerModule} from '@angular/material/divider';



const route: Routes =[
  {
    path:'profile',
    component: UsersProfileComponent
  }
]

@NgModule({
  declarations: [
    UsersProfileComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(route),
    MatMenuModule,
    FormsModule,
    MatDividerModule,
    ReactiveFormsModule
  ]
})
export class UsersModule { }
