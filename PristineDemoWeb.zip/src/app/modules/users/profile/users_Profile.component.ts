import { Component, OnInit } from '@angular/core';
import { SessionManagement } from '@pristine/process/SessionManagement';
import { expandCollapse } from '@pristine/animations/expand-collapse'
import {MatDialog,MatDialogRef} from "@angular/material/dialog";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'users_profile',
  templateUrl: './users_Profile.component.html',
  styleUrls: ['./users_Profile.component.scss'],
  animations:[expandCollapse]
})
export class UsersProfileComponent implements OnInit {
  constructor(private _session:SessionManagement,
              public _dialog:MatDialog,) {}
  userDetails: any ;
  showDets: boolean = false;
  ngOnInit(): void {
    this.userDetails= {
        name:this._session.getName,
         email:this._session.getEmail,
         location:this._session.getLocationName,
         role:this._session.getRoleName,
         img:this._session.getUserImg
    }
    // if (this.userDetails.img=='' || this.userDetails.img==null || this.userDetails.img==undefined)
    // {
    //     this.pic_url='/assets/images/avatars/default_img.png'
    // }else{
    //     this.pic_url=this.userDetails.img
    // }
    console.log(this.userDetails)
    console.log("profile img => ",this.userDetails.img)
  }
    for_Edit:boolean=false
    Edit_fun()
    {
        this.for_Edit= !this.for_Edit
    }
    openDialog(ref:any)
    {
        console.log(ref)
        let dia_ref=this._dialog.open(ref,{
            width:'600px',
            height:'310px',
        })
        // dia_ref.disableClose=true
    }

    pic_url="/assets/images/avatars/default_img.png";
    change_pic(event:any)
    {
        if(event.target.files && event.target.files[0])
        {
            let reader = new FileReader()
            reader.readAsDataURL(event.target.files[0])
            reader.onload=(event)=>{
                // @ts-ignore
                this.pic_url=event.target?.result
            }
        }
    }
    delete_pic()
    {
        this.pic_url="/assets/no_photo.jpg ";
    }
    tool_massage:string='Primary Email Address.\n We use your primary email address for all communications with you, which includes announcements, notifications, and alerts.'
}
