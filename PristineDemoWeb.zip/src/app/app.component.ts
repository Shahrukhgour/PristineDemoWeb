/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/member-ordering */
/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import {AppService} from  '../app/app.service';
import {HttpClient, HttpHeaders, HttpRequest} from '@angular/common/http';


@Component({
    selector   : 'app-root',
    templateUrl: './app.component.html',
    styleUrls  : ['./app.component.scss']
})
export class AppComponent implements OnInit {
    ngOnInit(): void {
    };

    scrollTo(ele: HTMLElement){
        ele.scrollIntoView({behavior:'smooth'});
    }


    DemoUser: FormGroup;
    constructor(private toast: ToastrService,
                private formBuilder: FormBuilder,
                private appService: AppService,
                private http: HttpClient) {
        this.DemoUser=formBuilder.group({
            name:['',Validators.required],
            phone:['',Validators.required],
            gmail:['',[Validators.email,Validators.required]],
            company:['',Validators.required],
            message:[''],
        });
    }
    clientData(){
        const json={
            name:this.DemoUser.get('name').value,
            phone:this.DemoUser.get('phone').value,
            email:this.DemoUser.get('gmail').value,
            company:this.DemoUser.get('company').value,
            message:this.DemoUser.get('message').value,
        };
        this.appService.getConfig(json).subscribe((result: any) => {
            if(result[0].condition.toLowerCase() == 'true'){
                this.toast.success('We Will Call You Shortly.','Thank You.');
            }
            if(result[0].condition.toLowerCase() == 'false'){
                this.toast.error('There are some problem.');
            }
            // console.log(result);
        });
        this.DemoUser.get('name').reset(),
        this.DemoUser.get('phone').reset(),
        this.DemoUser.get('gmail').reset(),
        this.DemoUser.get('company').reset(),
        this.DemoUser.get('message').reset();
    };

    hoemTage: boolean=true;
    servicesTag: boolean=false;
    aboutTag: boolean=false;
    industryTag: boolean=false;
    contect_usTag: boolean=false;
    partners_tag: boolean=false;
    colorChange(event: any){
        console.log(event.target.value)
        if (event.target.value=='services'){
            this.servicesTag=true;
            this.hoemTage=false;
            this.aboutTag=false;
            this.industryTag=false;
            this.contect_usTag=false;
            this.partners_tag=false;
        }
        else if(event.target.value=='about'){
            this.servicesTag=false;
            this.hoemTage=false;
            this.aboutTag=true;
            this.industryTag=false;
            this.contect_usTag=false;
            this.partners_tag=false;
        }
        else if(event.target.value=='industry'){
            this.servicesTag=false;
            this.hoemTage=false;
            this.aboutTag=false;
            this.industryTag=true;
            this.contect_usTag=false;
            this.partners_tag=false;
        }
        else if(event.target.value=='contect_us'){
            this.servicesTag=false;
            this.hoemTage=false;
            this.aboutTag=false;
            this.industryTag=false;
            this.contect_usTag=true;
            this.partners_tag=false;
        }
        else if(event.target.value=='home'){
            this.servicesTag=false;
            this.hoemTage=true;
            this.aboutTag=false;
            this.industryTag=false;
            this.contect_usTag=false;
            this.partners_tag=false;
        }
        else if(event.target.value=='partner'){
            this.servicesTag=false;
            this.hoemTage=false;
            this.aboutTag=false;
            this.industryTag=false;
            this.contect_usTag=false;
            this.partners_tag=true;
        }
    }
    onScroll(eve: any){
        // console.log(eve.target.scrollTop)
        //
        // if (eve.target.scrollTop>=100 && eve.target.scrollTop<=737){
        //     this.servicesTag=true
        //     this.hoemTage=false
        //     this.aboutTag=false
        //     this.industryTag=false
        //     this.contect_usTag=false
        // }
        // else if(eve.target.scrollTop>=837 && eve.target.scrollTop<=1394){
        //     this.servicesTag=false
        //     this.hoemTage=false
        //     this.aboutTag=true
        //     this.industryTag=false
        //     this.contect_usTag=false
        // }
        // else if(eve.target.scrollTop>=1494 && eve.target.scrollTop<=2051){
        //     this.servicesTag=false
        //     this.hoemTage=false
        //     this.aboutTag=false
        //     this.industryTag=true
        //     this.contect_usTag=false
        // }
        // else if(eve.target.scrollTop>=2728 && eve.target.scrollTop<=2908){
        //     this.servicesTag=false
        //     this.hoemTage=false
        //     this.aboutTag=false
        //     this.industryTag=false
        //     this.contect_usTag=false
        //     this.partners_tag=true
        // }
        // else if(eve.target.scrollTop>=0 && eve.target.scrollTop<=100){
        //     this.servicesTag=false
        //     this.hoemTage=true
        //     this.aboutTag=false
        //     this.industryTag=false
        //     this.contect_usTag=false
        // }
    }
}
