import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {WebApiHttp} from "../@pristine/process/WebApiHttp.services";
@Injectable({
  providedIn: 'root'
})
export class AppService {
  constructor(private http: HttpClient,
              private webapi:WebApiHttp){}

  getConfig(json: any): Observable<any>{
    let url ="https://social.pristinebs.com/api/Demo/DemoClientInsert"
    return this.http.post(url,json);
  }
}
