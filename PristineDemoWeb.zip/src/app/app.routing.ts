import { Route } from '@angular/router';
import { AuthGuard } from 'app/core/auth/guards/auth.guard';
import { NoAuthGuard } from 'app/core/auth/guards/noAuth.guard';
import { LayoutComponent } from 'app/layout/layout.component';
import { InitialDataResolver } from 'app/app.resolvers';
import {ExampleComponent} from "./modules/admin/example/example.component";
import {LeadsComponent} from "./modules/leads/leads.component";
import {LandingHomeModule} from "./modules/landing/home/home.module"
// @formatter:off
/* eslint-disable max-len */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
export const appRoutes: Route[] = [

    // {path: 'signed-in-redirect', pathMatch : 'full', redirectTo: 'example'},
    {path: '',
    data: {
            layout: 'empty'
        },
        loadChildren: () => import('app/modules/auth/sign-in/sign-in.module').then(m => m.AuthSignInModule)},

    {path:'dashboard',
        children   : [
            {path: '', loadChildren: () => import('app/modules/landing/home/home.module').then(m => m.LandingHomeModule)},
        ]
    },

    {
        path:'crm',
        // canActivate: [AuthGuard],
        // component: LeadsComponent
        children: [
            // {path: 'lead_list',component: LeadsComponent},
            {path: '',loadChildren :()=>import('app/modules/leads/leads.module').then(m => m.LeadsModule)},
            ]

    },
    {
        path:'users',
        // canActivate: [AuthGuard],
        // component: LeadsComponent
        children: [
            {path: '',loadChildren :()=>import('app/modules/users/users.module').then(m => m.UsersModule)},
            ]

    },

    {
        path:'**',  redirectTo:'/sign-in'
    },
];
