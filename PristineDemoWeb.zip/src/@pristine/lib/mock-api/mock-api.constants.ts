import { InjectionToken } from '@angular/core';

export const PRISTINE_MOCK_API_DEFAULT_DELAY = new InjectionToken<number>('PRISTINE_MOCK_API_DEFAULT_DELAY');
