export * from '@pristine/components/highlight/highlight.component';
export * from '@pristine/components/highlight/highlight.module';
export * from '@pristine/components/highlight/highlight.service';
