export * from '@pristine/components/fullscreen/fullscreen.component';
export * from '@pristine/components/fullscreen/fullscreen.module';
export * from '@pristine/components/fullscreen/fullscreen.types';
