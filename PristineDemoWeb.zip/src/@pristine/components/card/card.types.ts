export type PristineCardFace =
    | 'front'
    | 'back';
