export * from '@pristine/components/card/card.component';
export * from '@pristine/components/card/card.module';
