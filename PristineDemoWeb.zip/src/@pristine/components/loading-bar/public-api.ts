export * from '@pristine/components/loading-bar/loading-bar.component';
export * from '@pristine/components/loading-bar/loading-bar.module';
