import { InjectionToken } from '@angular/core';

export const PRISTINE_APP_CONFIG = new InjectionToken<any>('PRISTINE_APP_CONFIG');
