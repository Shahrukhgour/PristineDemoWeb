export * from '@pristine/directives/scrollbar/scrollbar.directive';
export * from '@pristine/directives/scrollbar/scrollbar.module';
