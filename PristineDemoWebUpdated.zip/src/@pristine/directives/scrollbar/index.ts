export * from '@pristine/directives/scrollbar/public-api';
